# Ansible Collection - my_own_namespace.yandex_cloud_elk

Учебный проект по Ansible от Netology
